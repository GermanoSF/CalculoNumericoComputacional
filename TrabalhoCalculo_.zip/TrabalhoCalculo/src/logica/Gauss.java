package logica;

public class Gauss {

    public Gauss() {}

    public String retornarValores(double[][] matriz) {
        int n = matriz.length;

        // --- 1. Eliminação (Triangulação) ---
        for (int i = 0; i < n; i++) {
            // Pivoteamento parcial simples (evitar divisão por zero)
            int pivo = i;
            for (int j = i + 1; j < n; j++) {
                if (Math.abs(matriz[j][i]) > Math.abs(matriz[pivo][i])) {
                    pivo = j;
                }
            }
            // Troca de linhas
            double[] temp = matriz[i];
            matriz[i] = matriz[pivo];
            matriz[pivo] = temp;

            // Zera os elementos abaixo do pivô
            for (int j = i + 1; j < n; j++) {
                double fator = matriz[j][i] / matriz[i][i];
                for (int k = i; k <= n; k++) {
                    matriz[j][k] -= fator * matriz[i][k];
                }
            }
        }

        // --- 2. Retrosubstituição ---
        double[] x = new double[n];
        for (int i = n - 1; i >= 0; i--) {
            double soma = 0;
            for (int j = i + 1; j < n; j++) {
                soma += matriz[i][j] * x[j];
            }
            x[i] = (matriz[i][n] - soma) / matriz[i][i];
        }

        // --- 3. Formatação da String de Retorno ---
        StringBuilder resultado = new StringBuilder();
        for (int i = 0; i < n; i++) {
            resultado.append(String.format("X%d=%.2f", (i + 1), x[i]));
            
            // Adiciona espaço entre os resultados, exceto no último
            if (i < n - 1) {
                resultado.append(" ");
            }
        }

        return resultado.toString();
    }
}