package logica;

import java.util.ArrayList;
import java.util.List;

public class GaussSeidel {
    
    private List<double[]> tabela = new ArrayList<>();
    private Object[][] tabelaR;
    private double[] dado;
    private double[] dados;
    private double maiorD;
    
    public GaussSeidel(){}
    
    private double maiorDiferenca(double[] antes, double[] depois){
        
        if (depois[0] - antes[0] >= 0) {
            this.maiorD = depois[0] - antes[0];
        } else {
            this.maiorD = antes[0] - depois[0];
        }
        
        for (int i = 1; i < depois.length - 1; i++) {
            double dif = (depois[i] - antes[i] >= 0) ? (depois[i] - antes[i]) : (antes[i] - depois[i]);
            if (dif > this.maiorD) {
                this.maiorD = dif;
            }
        }
        return this.maiorD;
    }
    
    private double todos (int i, double[] matriz, double[] listaAtualizada){
        double resultado = 0;
        for (int l = 0; l < matriz.length - 1; l++){
            if (l != i){

                resultado += matriz[l] * listaAtualizada[l];
            }
        }
        return resultado;
    }
    
    public Object[][] retornarValores(double[][] matriz, double tolerancia){
        // Reinicia a lista para não acumular lixo de execuções anteriores
        this.tabela = new ArrayList<>();
        
        int n = matriz.length; 
        this.dado = new double[n]; // Para X0, X1...
        this.dados = new double[n + 1]; // Para X0, X1... + Erro
        
        for (int i = 0; i < n; i++) this.dado[i] = 0;
        this.tabela.add(this.dado.clone());
        
        int i = 0;
        boolean continua = true;
        int s = 0; 
        
        // Vetor auxiliar para manter os valores sendo atualizados (característica do Gauss-Seidel)
        double[] valoresEmCalculo = new double[n];
        for (int k = 0; k < n; k++) valoresEmCalculo[k] = 0;

        while(continua){
            // Calcula o valor atualizado de Xi
            this.dados[i] = (matriz[i][n] - todos(i, matriz[i], valoresEmCalculo)) / matriz[i][i];
            
            // Atualiza imediatamente para o próximo cálculo na mesma iteração
            valoresEmCalculo[i] = this.dados[i];
            
            if (i < n - 1){
                i++;
            }
            else{
                // Fim da linha: calcula erro e salva
                this.dados[i + 1] = maiorDiferenca(this.tabela.get(s), this.dados.clone());
                this.tabela.add(this.dados.clone());
                
                s += 1;
                
                if (this.dados[i + 1] < tolerancia || s > 200){
                    continua = false;
                }
                
                i = 0;
                // Sincroniza o vetor de cálculo para a próxima iteração
                System.arraycopy(this.dados, 0, valoresEmCalculo, 0, n);
            }
        }

        this.tabelaR = new Object[this.tabela.size()][this.tabela.get(1).length];
        
        int v;
        for (v = 0; v < this.tabela.get(0).length; v++){
            this.tabelaR[0][v] = 0;
        }

        this.tabelaR[0][v] = "-";
        
        for (int j = 1; j < this.tabela.size(); j++){
            for (int k = 0; k < this.tabela.get(1).length; k++){
                this.tabelaR[j][k] = String.format("%.5f", this.tabela.get(j)[k]);
            }
        }
        
        return this.tabelaR.clone();
    }
}