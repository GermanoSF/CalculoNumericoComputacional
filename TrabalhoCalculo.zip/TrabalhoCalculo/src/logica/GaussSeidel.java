package logica;

import java.util.ArrayList;
import java.util.List;

/**
 * Método de Gauss-Seidel 
 * Adaptado para compatibilidade total com ResolucaoJacobiESeidel
 * @author gspal
 */
public class GaussSeidel {
    
    private List<double[]> tabela = new ArrayList<>();
    private Object[][] tabelaR;
    private double[] dado;
    private double[] dados;
    private double maiorD;
    
    public GaussSeidel(){}
    
    private double maiorDiferenca(double[] antes, double[] depois){
        // Calcula a maior diferença absoluta entre as variáveis (ignorando a coluna de erro)
        this.maiorD = Math.abs(depois[0] - antes[0]);
        
        for (int i = 1; i < depois.length - 1; i++){
            double dif = Math.abs(depois[i] - antes[i]);
            if (dif > this.maiorD){
                this.maiorD = dif;
            }
        }
        return this.maiorD;
    }
    
    private double todos (int i, double[] matriz, double[] listaAtualizada){
        double resultado = 0;
        for (int l = 0; l < matriz.length - 1; l++){
            if (l != i){
                // GAUSS-SEIDEL: Usa os valores já atualizados na iteração corrente
                resultado += matriz[l] * listaAtualizada[l];
            }
        }
        return resultado;
    }
    
    public Object[][] retornarValores(double[][] matriz, double tolerancia){
        // Reinicializa a lista para evitar acúmulo de dados entre execuções
        this.tabela = new ArrayList<>();
        
        int n = matriz.length; // Quantidade de variáveis
        this.dado = new double[n]; // Array para X0, X1...
        this.dados = new double[n + 1]; // Array para X0, X1... + Erro
        
        // Chute inicial (Iteração 0)
        for (int i = 0; i < n; i++) this.dado[i] = 0;
        this.tabela.add(this.dado.clone());
        
        int i = 0;
        boolean continua = true;
        int s = 0; // Ponteiro para a iteração anterior
        
        // Array auxiliar para o conceito de "memória atualizada" do Gauss-Seidel
        double[] valoresEmCalculo = new double[n];
        for (int k = 0; k < n; k++) valoresEmCalculo[k] = 0;

        while(continua){
            // Calcula o novo valor de Xi usando os valores mais recentes (Gauss-Seidel)
            this.dados[i] = (matriz[i][n] - todos(i, matriz[i], valoresEmCalculo)) / matriz[i][i];
            
            // Atualiza IMEDIATAMENTE o valor para ser usado no próximo cálculo desta mesma iteração
            valoresEmCalculo[i] = this.dados[i];
            
            if (i < n - 1){
                i++;
            }
            else{
                // Fim de uma linha completa de variáveis: calcula o erro
                this.dados[i + 1] = maiorDiferenca(this.tabela.get(s), this.dados.clone());
                
                this.tabela.add(this.dados.clone());
                s += 1;
                
                if (this.dados[i + 1] < tolerancia || s > 200){
                    continua = false;
                }
                
                i = 0;
                // Prepara o array auxiliar para a próxima iteração com os valores recém-obtidos
                System.arraycopy(this.dados, 0, valoresEmCalculo, 0, n);
            }
        }
        
        // --- FORMATAÇÃO PARA O JFRAME (Object[][]) ---
        // A largura da tabelaR deve ser n + 1 (Variáveis + Erro)
        this.tabelaR = new Object[this.tabela.size()][n + 1];
        
        // Preenche Iteração 0
        int v;
        for (v = 0; v < n; v++){
            this.tabelaR[0][v] = 0; 
        }
        this.tabelaR[0][v] = "-"; // O erro da iteração 0 é o traço esperado pelo JFrame
        
        // Preenche as iterações de cálculo
        for (int j = 1; j < this.tabela.size(); j++){
            for (int k = 0; k < n + 1; k++){
                this.tabelaR[j][k] = String.format("%.5f", this.tabela.get(j)[k]);
            }
        }
        
        return this.tabelaR.clone();
    }
}