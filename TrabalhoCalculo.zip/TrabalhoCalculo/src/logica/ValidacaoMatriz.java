package logica;

/**
 * Classe responsável por validar se a matriz converge para métodos iterativos
 * @author gspal (adaptado)
 */
public class ValidacaoMatriz {

    public ValidacaoMatriz() {}

    /**
     * Verifica o Critério das Linhas (Diagonal Dominante)
     * |a_ii| > soma(|a_ij|) para j != i
     * @param matriz A matriz ampliada (coeficientes + termos independentes)
     * @return true se a matriz for diagonal dominante
     */
    public boolean isDiagonalDominante(double[][] matriz) {
        int n = matriz.length;

        for (int i = 0; i < n; i++) {
            double soma = 0;
            double diagonal = Math.abs(matriz[i][i]);

            for (int j = 0; j < n; j++) {
                if (i != j) {
                    soma += Math.abs(matriz[i][j]);
                }
            }

            if (diagonal <= soma) {
                return false; // Se uma linha falhar, o critério não é satisfeito
            }
        }
        return true;
    }

    /**
     * Verifica se existe algum zero na diagonal principal.
     * Métodos como Jacobi e Gauss-Seidel não permitem divisão por zero.
     */
    public boolean possuiZeroNaDiagonal(double[][] matriz) {
        for (int i = 0; i < matriz.length; i++) {
            if (matriz[i][i] == 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * Tenta validar a matriz por completo
     * @return String com o erro ou "OK" se estiver tudo certo
     */
    public boolean validar(double[][] matriz) {
        if (possuiZeroNaDiagonal(matriz)) {
            return false;
        }
        
        if (!isDiagonalDominante(matriz)) {
            return false;
        }

        return true;
    }
}