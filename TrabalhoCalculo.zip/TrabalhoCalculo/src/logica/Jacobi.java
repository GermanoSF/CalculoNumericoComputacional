/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author gspal
 */
public class Jacobi {
    
    private List<double[]> tabela = new ArrayList<>();
    private Object[][] tabelaR;
    private double[] dado;
    private double[] dado2;
    private double[] dados;
    private double maiorD;
    
    public Jacobi(){}
    
    private double maiorDiferenca(double[] antes,double[] depois){
        
        if (depois[0]-antes[0]>=0){
        
            this.maiorD = depois[0]-antes[0];
        
        }
        else{
            
            this.maiorD = antes[0]-depois[0];
            
        }
        
        for (int i=1;i<depois.length-1;i++){
            
            if (depois[i]-antes[i]>this.maiorD){
                
                this.maiorD = depois[i]-antes[i];
                
            }
            else{
                
                if (antes[i]-depois[i]>this.maiorD){
                    
                    this.maiorD = antes[i]-depois[i];
                    
                }
                
            }
            
        }
        
        return this.maiorD;
        
    }
    
    private double todos (int i,double[] matriz,double[] lista){
        
        double resultado = 0;
        
        for (int l=0;l<matriz.length-1;l++){
            
            if (l!=i){
                
                resultado+=matriz[l]*lista[l];
                
            }
            
        }
        
        return resultado;
        
    }
    
    public Object[][] retornarValores(double[][] matriz, double tolerancia){
        
        this.dado = new double[matriz[0].length-1];
        this.dados = new double[matriz[0].length];
        
        for (int i=0;i<this.dado.length;i++)this.dado[i] = 0;
        
        this.tabela.add(this.dado.clone());
        
        int i = 0;
        boolean continua = true;
        
        int s = 0;
        
        while(continua){
            
            this.dados[i] = (matriz[i][matriz[0].length-1]-todos(i,matriz[i].clone(),this.tabela.get(s).clone()))/matriz[i][i]; 
            
            if (i<matriz[0].length-2){
                
                i++;
                
            }
            else{
                
                this.dados[i+1] = 0;
                this.dados[i+1] = maiorDiferenca(this.tabela.get(s),this.dados.clone());
                
                this.tabela.add(dados.clone());
                
                s+=1;
                               
                if (this.dados[i+1]<tolerancia){
                    
                    continua = false;
                    
                }
                
                i = 0;
                
            }
            
        }
        
        this.tabelaR = new Object[this.tabela.size()][this.tabela.get(1).length];
        
        int v;
        
        for (v=0;v<this.tabela.get(0).length;v++){
            
            this.tabelaR[0][v] = 0;
            
        }
        
        this.tabelaR[0][v] = '-';
        
        for (int j=1;j<this.tabela.size();j++){
            
            for (int k=0;k<this.tabela.get(1).length;k++){
                
                this.tabelaR[j][k] = String.format("%.5f",this.tabela.get(j)[k]);
                    
            }
            
        }
        
        return this.tabelaR.clone();
        
    }
    
}
